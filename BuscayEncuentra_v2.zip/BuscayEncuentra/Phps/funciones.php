<?php
function ObtenerServicios()
{
    try {

        //Sentencia sql
        require "conectar.php";//llamamos a la funcion(archivo) para conectar la bd
        var_dump($db);

        $select= "SELECT * FROM administradores;";
        $consultar= mysqli_query($db,$select);//funciona asi: mysqli_query(conexion,sentenci SQL)

        //resultados
        //$resultado=mysqli_fetch_assoc($consultar);

        echo "----------------------------";
        var_dump(mysqli_fetch_assoc($consultar));
        echo "----------------------------";

        /*
        echo ("\t");
        echo $resultado["username"];
        echo ("\t");
        echo $resultado["correo"];
        echo ("\t");
        echo $resultado["contrasena"];*/
       

    } 
    catch (\Throwable $th) 
    {
        var_dump($th);
    }
}

ObtenerServicios();


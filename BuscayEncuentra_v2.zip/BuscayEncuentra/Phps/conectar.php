<?php
    $db = mysqli_connect('localhost','root','123456','sysbusca&encuentra');
    if(!$db)
    {
        echo("Error de conexion");
        exit;
    }
   echo ("Conexion correcta");
